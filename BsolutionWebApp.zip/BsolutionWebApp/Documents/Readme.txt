We Are   using

sql server 2008 r2

database found above .rar