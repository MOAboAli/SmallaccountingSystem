﻿using System.Web.UI;

namespace BsolutionWebApp.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}